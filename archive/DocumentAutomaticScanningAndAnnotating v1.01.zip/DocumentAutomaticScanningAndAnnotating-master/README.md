# DocumentAutomaticScanningAndAnnotating
##### Version: 1.00
##### Author: Bratulescu Valentin Silviu

## Synopsis
DocumentAutomaticScanningAndAnnotating

## Installation

## Configuration
    
## System Dependencies

## Developer Notes

## PM Notes